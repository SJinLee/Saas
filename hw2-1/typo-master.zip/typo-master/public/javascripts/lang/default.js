window._lang = "en_US" ;
window._l10s = window._l10s || { } ;
window._l10s["en_US"] = {

  "#{0} from now": "#{0} from now",
  "#{0} ago": "#{0} ago",
  "on #{0}": "on #{0}",
  "less than a minute": "less than a minute",
  "#{0} minute": "#{0} minute",
  "#{0} minutes": "#{0} minutes",
  "about one hour": "about one hour",
  "#{0} hours": "#{0} hours",
  "one day": "one day",
  "about one day": "about one day",
  "#{0} days": "#{0} days"

} ;




