window._lang = "da_DK" ;
window._l10s = window._l10s || { } ;
window._l10s["da_DK"] = {
 
  "#{0} from now": "#{0} fra nn",
  "#{0} ago": "#{0} siden",
  "on #{0}": "på #{0}",
  "less than a minute": "mindre end et minut",
  "#{0} minute": "#{0} minut",
  "#{0} minutes": "#{0} minutter",
  "about one hour": "omkring en time",
  "#{0} hours": "#{0} timer",
  "one day": "en dag",
  "about one day": "ca. en dag",
  "#{0} days": "#{0} dage"

};