Date.weekdays = $w("Ma Ti Ke To Pe La Su");
Date.months = $w("Tammikuu Helmikuu Maaliskuu Huhtikuu Toukokuu Kes�kuu Hein�kuu Elokuu Syyskuu Lokakuu Marraskuu Joulukuu" );

Date.first_day_of_week = 1

_translations = {
  "OK": "OK",
  "Now": "Nyt",
  "Today": "T�n��n"
}